﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using E_Bibliothèque.Models;

namespace E_Bibliothèque.Models
{
    public class DAL : IDAL
    {

        private BddContext bdd;
         public  DAL()
        {
            bdd = new BddContext();
        }
        public Livre AfficherUnLivre_ParID(int id)
        {
            return bdd.Livres.FirstOrDefault(u => u.IdLivre == id);
        }

        public void Dispose()
        {
            bdd.Dispose();
        }

        public List<Auteur> ListeTousLesAuteurs()
        {
            return bdd.Auteurs.ToList();
        }

        public List<Livre> ListeTousLesLivres()
        {
            return bdd.Livres.ToList();
        }

        public List<Livre> ListeTousLesLivres_AuteurParID(int id)
        {
            List<Auteur> auteurs = ListeTousLesAuteurs().ToList();
            List<Livre> livres = new List<Livre>().ToList();
            Livre MonAuteur = bdd.Livres.First(s => s.UnAuteur.IdAuteur == id);
            int idAuteur = 0;           //  = grouping;
            //Auteur auteur = auteurs.First(r => r.IdAuteur == idAuteur);
            //    livres.Add(new Livre { TitreLivre = MonAuteur.UnAuteur.IdAuteur });

            
            return livres;
        }
      public void CreerUnLivre(int id, string titre, DateTime date)
        {
            bdd.Livres.Add(new Livre {IdLivre = id, TitreLivre = titre, DateParition = date });
            bdd.SaveChanges();
        }
        object IDAL.GroupBy(int id)
        {
           return id.ToString();
        }
    }
}