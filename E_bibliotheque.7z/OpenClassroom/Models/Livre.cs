﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace E_Bibliothèque.Models
{
    [Table("Livre")]
    public class Livre
    {
        [Key]
        public int IdLivre { get; set; }
        public string TitreLivre { get; set; }
        public DateTime DateParition { get; set; }
     //  [ForeignKey("IdAuteur")]
      public virtual Auteur UnAuteur { get; set; }
        
         
        
       
        
    }
}