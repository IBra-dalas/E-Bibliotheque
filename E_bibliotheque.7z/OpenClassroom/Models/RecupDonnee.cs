﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;
using System.Web.Configuration;

namespace E_Bibliothèque.Models
{
    interface IRecupDonnee : IDisposable
    {
       
       

    }
}
